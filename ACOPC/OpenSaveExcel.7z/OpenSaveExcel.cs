﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace ACOPC
{
    class MeasureList
    {
        public string YUnits;
        public string XUnits;
        public List<double> XValues;
        public struct MeasureItem
        {
            public string Name;
            public List<double> YValues;
        };
        public List<MeasureItem> Measures;

        public MeasureList()
        {
            XValues = new List<double>();
            Measures = new List<MeasureItem>();
        }

        public bool AddXRange(IEnumerable<string> Values)
        {
            try
            {
                foreach (var value in Values)
                {
                    XValues.Add(double.Parse(value));
                }
                return true;
            }
            catch (Exception) { return false; }
        }

        public void AddMeasure(string MeasureName, IEnumerable<double> Values)
        {
            MeasureItem mi = new MeasureItem();
            mi.Name = MeasureName;
            mi.YValues = new List<double>();
            mi.YValues.AddRange(Values);
            Measures.Add(mi);
        }

        public void AddMeasure(MeasureItem mi)
        {
            Measures.Add(mi);
        }
    }

    class ExcelService
    {
        private _Worksheet worksheet;
        
        class ComObject<TType> : IDisposable
        {
            public TType Instance { get; set; }

            public ComObject(TType instance)
            {
                this.Instance = instance;
            }

            public void Dispose()
            {
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(this.Instance);
            }
        }

        public void Load(string FileName, out MeasureList mlAnalyser, out MeasureList mlMonitor)
        {
            string tmpStr;
            int CurrentRow;
            int CurrentColumn;
            double tmpValue;
            string measname;
            MeasureList.MeasureItem mi;

            mlAnalyser = null;
            mlMonitor = null;
            
            using (var comApplication = new ComObject<Application>(new Application()))
            {
                var excelInstance = comApplication.Instance;
                excelInstance.Visible = false;
                excelInstance.DisplayAlerts = false;

                try
                {
                    using (var workbooks = new ComObject<Workbooks>(excelInstance.Workbooks))
                    using (var workbook = new ComObject<_Workbook>(workbooks.Instance.Open(FileName)))
                    using (var comSheets = new ComObject<Sheets>(workbook.Instance.Sheets))
                    {
                        foreach(_Worksheet sh in comSheets.Instance)
                        {
                            if(sh.Name == "Анализатор.Данные")
                            {
                                mlAnalyser = new MeasureList();
                            }else if (sh.Name == "Монитор.Данные")
                            {
                                mlMonitor = new MeasureList();
                            }
                            Marshal.ReleaseComObject(sh);
                        }
                        
                        if (mlAnalyser != null)
                        {
                            this.worksheet = (Worksheet)comSheets.Instance.get_Item("Анализатор.Данные");
                            Range rangeCells = this.worksheet.Cells;

                            var currentCell = (Range)rangeCells[1, 1];
                            tmpStr = currentCell.Text;
                            Marshal.ReleaseComObject(currentCell);
                            if (tmpStr.Split(',').Count() > 1)
                                mlAnalyser.XUnits = tmpStr.Split(',')[1].Trim();
                            else
                                mlAnalyser.XUnits = "Гц";

                            currentCell = (Range)rangeCells[1, 2];
                            tmpStr = currentCell.Text;
                            Marshal.ReleaseComObject(currentCell);
                            if (tmpStr.Split(',').Count() > 1)
                                mlAnalyser.YUnits = tmpStr.Split(',')[1].Trim();
                            else
                                mlAnalyser.YUnits = "дБм";


                            CurrentRow = 2;
                            do      // Читаем частоты
                            {
                                currentCell = (Range)rangeCells[CurrentRow, 1];
                                tmpStr = currentCell.Text;
                                Marshal.ReleaseComObject(currentCell);
                                if (double.TryParse(tmpStr, out tmpValue))
                                {
                                    mlAnalyser.XValues.Add(tmpValue);
                                }
                                else break;
                                CurrentRow++;
                            } while (tmpStr != "");

                            CurrentColumn = 2;

                            currentCell = (Range)rangeCells[1, CurrentColumn];
                            measname = currentCell.Text;
                            Marshal.ReleaseComObject(currentCell);

                            while (measname != "")  // пока в заголовке измерения не пусто
                            {
                                CurrentRow = 2;
                                mi = new MeasureList.MeasureItem();  // создаем измерение
                                mi.Name = measname.Split(',')[0];
                                mi.YValues = new List<double>();
                                do      // Читаем измерение
                                {
                                    currentCell = (Range)rangeCells[CurrentRow, CurrentColumn];
                                    tmpStr = currentCell.Text;
                                    Marshal.ReleaseComObject(currentCell);

                                    if (double.TryParse(tmpStr, out tmpValue))  // если парсится, добавляем точку
                                    {
                                        mi.YValues.Add(tmpValue);
                                    }
                                    else break;
                                    CurrentRow++;
                                } while (tmpStr != "");
                                mlAnalyser.AddMeasure(mi);  // добавляем измерение в список
                                CurrentColumn++;

                                currentCell = (Range)rangeCells[1, CurrentColumn];
                                measname = currentCell.Text;
                                Marshal.ReleaseComObject(currentCell);
                            }

                            Marshal.ReleaseComObject(rangeCells);
                            Marshal.ReleaseComObject(this.worksheet);
                        }

                        

                        if (mlMonitor != null)
                        {
                            this.worksheet = (Worksheet)comSheets.Instance.get_Item("Монитор.Данные");
                            Range rangeCells = this.worksheet.Cells;

                            var currentCell = (Range)rangeCells[1, 1];
                            tmpStr = currentCell.Text;
                            Marshal.ReleaseComObject(currentCell);
                            if (tmpStr.Split(',').Count() > 1)
                                mlMonitor.XUnits = tmpStr.Split(',')[1].Trim();
                            else
                                mlMonitor.XUnits = "Гц";

                            currentCell = (Range)rangeCells[1, 2];
                            tmpStr = currentCell.Text;
                            Marshal.ReleaseComObject(currentCell);
                            if (tmpStr.Split(',').Count() > 1)
                                mlMonitor.YUnits = tmpStr.Split(',')[1].Trim();
                            else
                                mlMonitor.YUnits = "дБм";


                            CurrentRow = 2;
                            do      // Читаем частоты
                            {
                                currentCell = (Range)rangeCells[CurrentRow, 1];
                                tmpStr = currentCell.Text;
                                Marshal.ReleaseComObject(currentCell);
                                if (double.TryParse(tmpStr, out tmpValue))
                                {
                                    mlMonitor.XValues.Add(tmpValue);
                                }
                                else break;
                                CurrentRow++;
                            } while (tmpStr != "");

                            CurrentColumn = 2;

                            currentCell = (Range)rangeCells[1, CurrentColumn];
                            measname = currentCell.Text;
                            Marshal.ReleaseComObject(currentCell);

                            while (measname != "")  // пока в заголовке измерения не пусто
                            {
                                CurrentRow = 2;
                                mi = new MeasureList.MeasureItem();  // создаем измерение
                                mi.Name = measname.Split(',')[0];
                                mi.YValues = new List<double>();
                                do      // Читаем измерение
                                {
                                    currentCell = (Range)rangeCells[CurrentRow, CurrentColumn];
                                    tmpStr = currentCell.Text;
                                    Marshal.ReleaseComObject(currentCell);

                                    if (double.TryParse(tmpStr, out tmpValue))  // если парсится, добавляем точку
                                    {
                                        mi.YValues.Add(tmpValue);
                                    }
                                    else break;
                                    CurrentRow++;
                                } while (tmpStr != "");
                                mlMonitor.AddMeasure(mi);  // добавляем измерение в список
                                CurrentColumn++;

                                currentCell = (Range)rangeCells[1, CurrentColumn];
                                measname = currentCell.Text;
                                Marshal.ReleaseComObject(currentCell);
                            }

                            Marshal.ReleaseComObject(rangeCells);
                            Marshal.ReleaseComObject(this.worksheet);
                        }
                    }
                }
                catch (Exception)
                {

                }
                finally
                {
                    // Close Excel instance
                    excelInstance.Quit();
                }
            }
        }

        public bool Save(string FileName, MeasureList mlAnalyser = null, MeasureList mlMonitor = null)
        {
            if ((mlAnalyser == null) && (mlMonitor == null)) return false;

            using (var comApplication = new ComObject<Application>(new Application()))
            {
                var excelInstance = comApplication.Instance;
                excelInstance.Visible = false;
                excelInstance.DisplayAlerts = false;

                try
                {
                    using (var workbooks = new ComObject<Workbooks>(excelInstance.Workbooks))
                    using (var workbook = new ComObject<_Workbook>(workbooks.Instance.Add()))
                    using (var comSheets = new ComObject<Sheets>(workbook.Instance.Sheets))
                    {
                        if(mlAnalyser != null)
                        {
                            using (var comSheet = new ComObject<_Worksheet>(comSheets.Instance.Add()))
                            {
                                this.worksheet = comSheet.Instance;
                                this.worksheet.Name = "Анализатор.Данные";

                                Range rangeCells = this.worksheet.Cells;

                                var currentCell = (Range)rangeCells[1, 1];
                                Range entireColumn = currentCell.EntireColumn;
                                entireColumn.AutoFit();
                                Marshal.ReleaseComObject(currentCell);
                                Marshal.ReleaseComObject(entireColumn);

                                //  Добавление частот
                                int row = 2;
                                rangeCells[1, 1] = "Частота, " + mlAnalyser.XUnits;
                                foreach (var p in mlAnalyser.XValues)
                                {
                                    rangeCells[row, 1] = p;
                                    row++;
                                }

                                //  Добавление измерений
                                int CurrentCol = 2;
                                foreach (var measure in mlAnalyser.Measures)
                                {
                                    row = 2;
                                    rangeCells[1, CurrentCol] = measure.Name + ", " + mlAnalyser.YUnits;

                                    currentCell = (Range)rangeCells[1, CurrentCol];
                                    entireColumn = currentCell.EntireColumn;
                                    entireColumn.AutoFit();
                                    Marshal.ReleaseComObject(currentCell);
                                    Marshal.ReleaseComObject(entireColumn);

                                    foreach (var y in measure.YValues)
                                    {
                                        rangeCells[row, CurrentCol] = y;
                                        row++;
                                    }
                                    CurrentCol++;
                                }
                                Marshal.ReleaseComObject(rangeCells);
                            }
                            
                            using (var comSheetData = new ComObject<_Worksheet>(comSheets.Instance["Анализатор.Данные"]))
                            using (var comSheet = new ComObject<_Worksheet>(comSheets.Instance.Add()))
                            {
                                var DataInstance = comSheetData.Instance;
                                this.worksheet = comSheet.Instance;
                                this.worksheet.Name = "Анализатор.График";
                                
                                Range rangeCells = comSheetData.Instance.Cells;

                                //  Добавление графика
                                string range;
                                int ColCount = mlAnalyser.Measures.Count + 1;
                                int RowCount = mlAnalyser.XValues.Count + 1;
                                if (ColCount > 26)
                                {
                                    range = "B1:" + (char)(ColCount / 26 + 64) + (char)(((float)ColCount / 26 - ColCount / 26) * 26 + 64) + RowCount.ToString();
                                }
                                else
                                {
                                    range = "B1:" + (char)(ColCount + 64) + RowCount.ToString();
                                }

                                using (var chartobjects = new ComObject<ChartObjects>(comSheet.Instance.ChartObjects()))
                                using (var chartobject = new ComObject<ChartObject>(chartobjects.Instance.Add(0, 0, 1000, 500)))
                                using (var comChart = new ComObject<Chart>(chartobject.Instance.Chart))
                                {
                                    var ChartInstance = comChart.Instance;
                                    using (var comRange = new ComObject<Range>(DataInstance.Range[range]))
                                    {
                                        ChartInstance.ChartType = XlChartType.xlLine;
                                        ChartInstance.SetSourceData(comRange.Instance, XlRowCol.xlColumns);
                                        using (var comAxis = new ComObject<Axis>(comChart.Instance.Axes(Excel.XlAxisType.xlCategory, Excel.XlAxisGroup.xlPrimary)))
                                        {
                                            var AxisInstance = comAxis.Instance;
                                            AxisInstance.HasTitle = true;
                                            var Title = AxisInstance.AxisTitle;
                                            var Cell = rangeCells[1, 1];
                                            Title.Text = Cell.Text;
                                            Marshal.FinalReleaseComObject(Cell);

                                            var DataRange = DataInstance.get_Range("A2", "A" + RowCount.ToString());
                                            AxisInstance.CategoryNames = DataRange;
                                            Marshal.FinalReleaseComObject(Title);
                                            Marshal.ReleaseComObject(DataRange);
                                        }
                                    }
                                }
                                Marshal.ReleaseComObject(rangeCells);
                            }
                        }

                        if (mlMonitor != null)
                        {
                            using (var comSheet = new ComObject<_Worksheet>(comSheets.Instance.Add()))
                            {
                                this.worksheet = comSheet.Instance;
                                this.worksheet.Name = "Монитор.Данные";

                                Range rangeCells = this.worksheet.Cells;

                                var currentCell = (Range)rangeCells[1, 1];
                                Range entireColumn = currentCell.EntireColumn;
                                entireColumn.AutoFit();
                                Marshal.ReleaseComObject(currentCell);
                                Marshal.ReleaseComObject(entireColumn);

                                //  Добавление частот
                                int row = 2;
                                rangeCells[1, 1] = "Частота, " + mlMonitor.XUnits;
                                foreach (var p in mlMonitor.XValues)
                                {
                                    rangeCells[row, 1] = p;
                                    row++;
                                }

                                //  Добавление измерений
                                int CurrentCol = 2;
                                foreach (var measure in mlMonitor.Measures)
                                {
                                    row = 2;
                                    rangeCells[1, CurrentCol] = measure.Name + ", " + mlMonitor.YUnits;

                                    currentCell = (Range)rangeCells[1, CurrentCol];
                                    entireColumn = currentCell.EntireColumn;
                                    entireColumn.AutoFit();
                                    Marshal.ReleaseComObject(currentCell);
                                    Marshal.ReleaseComObject(entireColumn);

                                    foreach (var y in measure.YValues)
                                    {
                                        rangeCells[row, CurrentCol] = y;
                                        row++;
                                    }
                                    CurrentCol++;
                                }
                                Marshal.ReleaseComObject(rangeCells);
                            }

                            using (var comSheetData = new ComObject<_Worksheet>(comSheets.Instance["Монитор.Данные"]))
                            using (var comSheet = new ComObject<_Worksheet>(comSheets.Instance.Add()))
                            {
                                var DataInstance = comSheetData.Instance;
                                this.worksheet = comSheet.Instance;
                                this.worksheet.Name = "Монитор.График";

                                Range rangeCells = comSheetData.Instance.Cells;

                                //  Добавление графика
                                string range;
                                int ColCount = mlMonitor.Measures.Count + 1;
                                int RowCount = mlMonitor.XValues.Count + 1;
                                if (ColCount > 26)
                                {
                                    range = "B1:" + (char)(ColCount / 26 + 64) + (char)(((float)ColCount / 26 - ColCount / 26) * 26 + 64) + RowCount.ToString();
                                }
                                else
                                {
                                    range = "B1:" + (char)(ColCount + 64) + RowCount.ToString();
                                }

                                using (var chartobjects = new ComObject<ChartObjects>(comSheet.Instance.ChartObjects()))
                                using (var chartobject = new ComObject<ChartObject>(chartobjects.Instance.Add(0, 0, 1000, 500)))
                                using (var comChart = new ComObject<Chart>(chartobject.Instance.Chart))
                                {
                                    var ChartInstance = comChart.Instance;
                                    using (var comRange = new ComObject<Range>(DataInstance.Range[range]))
                                    {
                                        ChartInstance.ChartType = XlChartType.xlLine;
                                        ChartInstance.SetSourceData(comRange.Instance, XlRowCol.xlColumns);
                                        using (var comAxis = new ComObject<Axis>(comChart.Instance.Axes(Excel.XlAxisType.xlCategory, Excel.XlAxisGroup.xlPrimary)))
                                        {
                                            var AxisInstance = comAxis.Instance;
                                            AxisInstance.HasTitle = true;
                                            var Title = AxisInstance.AxisTitle;
                                            var Cell = rangeCells[1, 1];
                                            Title.Text = Cell.Text;
                                            Marshal.FinalReleaseComObject(Cell);

                                            var DataRange = DataInstance.get_Range("A2", "A" + RowCount.ToString());
                                            AxisInstance.CategoryNames = DataRange;
                                            Marshal.FinalReleaseComObject(Title);
                                            Marshal.ReleaseComObject(DataRange);
                                        }
                                    }
                                }
                                Marshal.ReleaseComObject(rangeCells);
                            }
                        }

                        if (FileName != null)
                        {
                            var currentWorkbook = (workbook.Instance as _Workbook);
                            currentWorkbook.SaveAs(FileName, XlFileFormat.xlWorkbookNormal);
                            currentWorkbook.Close(false);
                            return true;
                        }
                    }
                    return false;
                }
                catch (Exception)
                {
                    return false;
                }
                finally
                {
                    // Close Excel instance
                    excelInstance.Quit();
                }
            }
        }
    }
}
